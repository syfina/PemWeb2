<?php
class Matakuliah_model extends CI_Model {
    // Buat Property atau Variabel
    public $nama;
    public $sks;
    public $kode;
}
?>