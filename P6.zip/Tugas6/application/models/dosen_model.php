<?php
class dosen_model extends CI_Model {
    public $id;
    public $nama;
    public $nidn;
    public $pendidikan;
    public $gender;
}
?>